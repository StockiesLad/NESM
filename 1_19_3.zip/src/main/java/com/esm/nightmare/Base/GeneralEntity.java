package com.esm.nightmare.Base;

import net.minecraft.world.entity.Entity;

public class GeneralEntity {

	//General properties to be set for all entities
	public GeneralEntity(Entity Entity_Class) {
		
		//Route to player
		
		
	}
}
