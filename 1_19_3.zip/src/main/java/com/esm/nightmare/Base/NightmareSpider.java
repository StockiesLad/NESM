package com.esm.nightmare.Base;

import net.minecraft.world.entity.Entity;

public class NightmareSpider {
 

	//Spawn a nightmare spider
	public NightmareSpider(Entity Entity_Class) 
	{         	
    	
	}
	
	
	

}
